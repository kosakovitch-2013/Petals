struct vk_properties {};
